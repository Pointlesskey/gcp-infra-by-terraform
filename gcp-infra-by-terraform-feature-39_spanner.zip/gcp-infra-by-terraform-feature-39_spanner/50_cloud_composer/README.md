# intro

Create Cloud Composer 2.

## Architecture

Below is an architectural image created after Terraform is executed.

![alt text](./images/50_cloud_composer.drawio.png)
