# intro
Create a VM instance

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/02_compute_engine.drawio.png)

## Precautions

A _health-check_ is included. _Health-check_ fails until the application is actually started.