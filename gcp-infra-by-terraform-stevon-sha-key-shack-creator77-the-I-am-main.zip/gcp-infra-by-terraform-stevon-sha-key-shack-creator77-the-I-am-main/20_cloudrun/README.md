# intro
Create an artifact registry and create a cloud run service that takes images from artifact_registry.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/20_cloudrun.drawio.png)