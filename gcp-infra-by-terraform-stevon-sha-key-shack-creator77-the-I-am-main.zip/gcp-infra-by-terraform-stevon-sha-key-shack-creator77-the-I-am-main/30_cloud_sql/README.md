# intro
Create a database.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/30_cloud_sql.drawio.png)