# Build a chat server with Cloud Run
![img.png](img.png)

See the links below for a detailed explanation.

https://cloud.google.com/blog/topics/developers-practitioners/build-chat-server-cloud-run?hl=en