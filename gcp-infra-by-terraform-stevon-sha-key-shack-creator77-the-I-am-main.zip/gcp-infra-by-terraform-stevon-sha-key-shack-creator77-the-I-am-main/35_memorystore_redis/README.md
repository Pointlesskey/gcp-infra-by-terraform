# intro
Create a memorystore(redis).

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/35_memorystore_redis.drawio.png)